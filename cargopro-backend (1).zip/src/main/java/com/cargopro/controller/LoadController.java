package com.cargopro.controller;

import com.cargopro.dto.LoadRequestDTO;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import jakarta.validation.Valid;
import java.util.UUID;

@RestController
@RequestMapping("/load")
public class LoadController {

    @PostMapping
    public ResponseEntity<?> createLoad(@Valid @RequestBody LoadRequestDTO dto) {
        // Stub
        return ResponseEntity.ok("Load created (stub)");
    }

    @GetMapping("/{id}")
    public ResponseEntity<?> getLoad(@PathVariable UUID id) {
        // Stub
        return ResponseEntity.ok("Load details (stub)");
    }
}