package com.cargopro.dto;

import jakarta.validation.constraints.*;
import java.sql.Timestamp;

public class LoadRequestDTO {
    @NotBlank private String shipperId;
    @NotBlank private String loadingPoint;
    @NotBlank private String unloadingPoint;
    @NotNull private Timestamp loadingDate;
    @NotNull private Timestamp unloadingDate;
    @NotBlank private String productType;
    @NotBlank private String truckType;
    @Positive private int noOfTrucks;
    @Positive private double weight;
    private String comment;

    // Getters and Setters
}