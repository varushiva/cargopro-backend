package com.cargopro.entity;

import jakarta.persistence.*;
import java.sql.Timestamp;
import java.util.UUID;

@Entity
public class Booking {
    @Id
    private UUID id;

    @ManyToOne
    @JoinColumn(name = "load_id")
    private Load load;

    private String transporterId;
    private double proposedRate;
    private String comment;

    @Enumerated(EnumType.STRING)
    private BookingStatus status;
    private Timestamp requestedAt;

    // Getters and Setters
}