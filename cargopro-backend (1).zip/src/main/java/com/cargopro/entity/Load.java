package com.cargopro.entity;

import jakarta.persistence.*;
import java.sql.Timestamp;
import java.util.*;

@Entity
public class Load {
    @Id
    private UUID id;

    private String shipperId;
    private String loadingPoint;
    private String unloadingPoint;
    private Timestamp loadingDate;
    private Timestamp unloadingDate;
    private String productType;
    private String truckType;
    private int noOfTrucks;
    private double weight;
    private String comment;
    private Timestamp datePosted;

    @Enumerated(EnumType.STRING)
    private LoadStatus status;

    @OneToMany(mappedBy = "load", cascade = CascadeType.ALL, orphanRemoval = true)
    private List<Booking> bookings = new ArrayList<>();

    // Getters and Setters
}