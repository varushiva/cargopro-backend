package com.cargopro.util;

public enum BookingStatus {
    PENDING,
    ACCEPTED,
    REJECTED
}