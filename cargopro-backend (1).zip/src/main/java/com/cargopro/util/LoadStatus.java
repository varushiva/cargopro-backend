package com.cargopro.util;

public enum LoadStatus {
    POSTED,
    BOOKED,
    CANCELLED
}